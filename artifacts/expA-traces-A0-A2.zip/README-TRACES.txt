Exp A traces pack (A0–A2) — unzip into the repo root (merge jobs/ and results/).

  bash scripts/analyze_characterization_wave.sh <prefix>

Prefixes:
  char-setup-10t-k5
  char-setup-10t-ctx256k-t100
  char-pilot1-clack-t500
  char-think1b-clack-t250
  char-kvpack-tp2-think-high-n10

Omitted: *orphaned* job dirs, run-batched.log (Harbor console spam), httpx-manual/monitor noise.
See docs/workload_characterization_report.md for cell meanings.
